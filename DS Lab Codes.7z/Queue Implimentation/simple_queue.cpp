#include<iostream>
using namespace std;
int front,rear,size,item,queue_arr[50],ch;
class queue
{
	public:
		
		void initialize()
		{
			front=0;
			rear=-1;
			cout<<"Enter size of queue : ";
			cin>>size;
		}
		void enqueue()
		{
			if(rear==size-1)
			{
				cout<<"Queue is overflow!!! Element cant be enqueued.\n";
			}
			else
			{
				rear=rear+1;
				cout<<"\nEnter number that you want to enqueue : ";
			    cin>>queue_arr[rear];
				cout<<"Element enqueued successfully.\n";
    		}
		}
		void dequeue()
		{
			if(front>rear)	
			{
				cout<<"Queue Underflow!!! Element cant be dequeued.\n";
			}
			else
			{
				item=queue_arr[front];
				front=front+1;	
				cout<<item<<" is dequeued successfully.\n";
    		}
		}
		void display()
		{
			if(front>rear)
			{
				cout<<"Queue is empty.\n";
			}
			else
			{		
				cout<<"\nQueue Elements :";
				for(int i=front;i<=rear;i++)
				{
					cout<<"  "<<queue_arr[i];;	
				}
				cout<<endl;
   			}
		}
		void menu()
		{
			do{
				cout<<"\nMenu :\n1.Enqueue\n2.Dequeue\n3.Display\n4.Exit\n";
				cout<<"Enter your choice : ";
				cin>>ch;
				switch(ch)
				{
					case 1:
				  	    enqueue();
				   		break;
					case 2:
				   		dequeue();
				    	break;
					case 3:
			        	display();
			    		break;	
					case 4:
			        	exit(0);
	     			default:
					cout<<"Invalid Choice.\n";
			    }
			}while(1);
		}
};
int main()
{
	queue q;
	q.initialize();
	q.menu();
	return 0;
}

