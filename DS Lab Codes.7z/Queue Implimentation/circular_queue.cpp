#include<iostream>
using namespace std;
int front,rear,size,item,cq_arr[50],ch;
class cqueue
{
	public:
	void initialize()
		{
			front=rear=-1;
			cout<<"Enter size of circular queue : ";
			cin>>size;
		}
		void enqueue()
		{
			if((rear==size-1 && front==0) || front==rear+1) 
			{
				cout<<"Queue is overflow!!! Element cant be enqueued.\n";
			}
			else 
			{
				cout<<"\nEnter number that you want to enqueue : ";
				cin>>item;
				if(front==-1)
				{
					front=0;
				}
				rear=(rear+1)%size;
				cq_arr[rear]=item;
				cout<<"Element enqueued successfully.\n";	
	    	}
		}
		void dequeue()
		{
			if(front==-1)
			{
				cout<<"Queue Underflow!!! Element cant be dequeued.\n";
			}
			else
			{
				item=cq_arr[front];
				if(front==rear)	
				{
					front=rear=-1;
				}
				else
				{
					front=(front+1)%size;	
		 		}
		 		cout<<item<<" is dequeued successfully.\n";
			}
		}
		void display()
		{
			int fp=front,rp=rear;
			if(front==-1)
			{
				cout<<"Queue is empty.\n";
			}
			else
			{		
				cout<<"\nQueue Elements :";
				if(fp<=rp)
				{
					while(fp<=rp)
					{
						cout<<"  "<<cq_arr[fp];
						fp=fp+1;
					}
				}
				else
				{
					while(fp<=size-1)
					{
						cout<<"  "<<cq_arr[fp];
						fp=fp+1;
					}
					fp=0;
					while(fp<=rp)
					{
						cout<<"  "<<cq_arr[fp];
						fp=fp+1; 
					}
				}
   			}
		}
		void menu()
		{
			do{
				cout<<"\nMenu :\n1.Enqueue\n2.Dequeue\n3.Display\n4.Exit\n";
				cout<<"Enter your choice : ";
				cin>>ch;
				switch(ch)
				{
					case 1:
				  	    enqueue();
				   		break;
					case 2:
				   		dequeue();
				    	break;
					case 3:
			        	display();
			    		break;	
					case 4:
			        	exit(0);
	     			default:
					cout<<"Invalid Choice.\n";
			    }
			}while(1);
		}
};
int main()
{
	cqueue cq;
	cq.initialize();
	cq.menu();
	return 0;
}

