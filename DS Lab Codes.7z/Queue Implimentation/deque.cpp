#include<iostream>
using namespace std;
int front,rear,size,item,d_arr[50],ch;
class deque
{
	public:
		void initialize()
		{
			front=rear=-1;
			cout<<"Enter size of queue : ";  
			cin>>size;
		}
		void insert_front()
		{
			if((front==0 &&  rear==size-1) || (front==rear+1))
			{
				cout<<"Queue is overflow!!! Element cant be enqueued.\n";
			}
			else
			{
				
				if(front==-1 && rear==-1)
				{
					front=rear=0;
				}
				else if(front==0)
				{
					front=size-1;
				}
				else
				{
					front=front-1;
				}
				cout<<"\nEnter number that you want to enqueue : ";
			    cin>>item;
				d_arr[front]=item;
				cout<<"Element enqueued successfully.\n";
    		}
		}
		void insert_rear()
		{
			if((front==0 &&  rear==size-1) || (front==rear+1))
			{
				cout<<"Queue is overflow!!! Element cant be enqueued.\n";
			}
			else
			{   
				if(front==-1 && rear==-1)
				{
					front=rear=0;
				}
				else if(rear==size-1)
				{
					rear=0;
				}
				else
				{
					rear=rear+1;
				}
				cout<<"\nEnter number that you want to enqueue : ";
			    cin>>item;
				d_arr[rear]=item;
				cout<<"Element enqueued successfully.\n";
    		}
		}
		void delete_front()
		{
			if(front==-1 && rear==-1)	
			{
				cout<<"Queue Underflow!!! Element cant be dequeued.\n";
			}
			else
			{
				item=d_arr[front];
				if(front==rear)
				{
					front=rear=-1;
				}
				else
				{
					if(front==size-1)
					{
						front=0;
					}
					else
					{
						front=front+1;	
					}	
				}
				cout<<item<<" is dequeued successfully.\n";
    		}
		}
		void delete_rear()
		{
			if(front==-1 && rear==-1)	
			{
				cout<<"Queue Underflow!!! Element cant be dequeued.\n";
			}
			else
			{
				item=d_arr[rear];
				if(rear==front)
				{
					front=rear=-1;
				}
				else
				{
					if(rear==0)
					{
						rear=size-1;
					}
					else
					{
						rear=rear-1;
					}
				}
				cout<<item<<" is dequeued successfully.\n";
    		}
		}
		void display()
		{
			if(front==-1 && rear==-1)
			{
				cout<<"Queue is empty.\n";
			}
			else
			{		
				cout<<"\nQueue Elements :";
				int i=front;
				while(i!=rear)
				{
					cout<<d_arr[i]<<" ";
					i=(i+1)%size;
				}
				cout<<d_arr[rear];
				cout<<endl;
   			}
		}
		void menu()
		{
			do{
				cout<<"\nMenu :\n1.Insert from front\n2.Insert from rear\n3.delete from front\n4.delete from rear\n5.Display\n6.Exit\n";
				cout<<"Enter your choice : ";
				cin>>ch;
				switch(ch)
				{
					case 1:
				  	    insert_front();
				   		break;
					case 2:
				   		insert_rear();
				    	break;
					case 3:
			        	delete_front();
			    		break;
					case 4:
			        	delete_rear();
			    		break;	
			    	case 5:
			        	display();
			    		break;
					case 6:
			        	exit(0); 
	     			default:
					cout<<"Invalid Choice.\n";
			    }
			}while(1);
		}
};
int main()
{
	deque q;
	q.initialize();
	q.menu();
	return 0;
}

