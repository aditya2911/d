#include<iostream>
using namespace std;
int front,rear,size,item,pr,ch;
struct pqueue{
	int element,priority;
};
class prio_queue
{
	public:
		struct pqueue pq[50],temp; 
		void initialize()
		{
			front=rear=-1;
			cout<<"Enter size of priority queue : ";
			cin>>size;
		}
		void enqueue()
		{
			if(rear==size-1)
			{
				cout<<"Priority queue is overflow!!! Element cant be enqueued.\n";
			}
			else
			{
				cout<<"\nEnter number that you want to enqueue : ";
			    cin>>item;
			    cout<<"\nEnter priority : ";
			    cin>>pr;
			    rear=rear+1;
			    pq[rear].element=item;
			    pq[rear].priority=pr;
			    if(front==-1)
			    {
			    	front=0;
				}
				for(int i=front;i<=rear;i++)
				{
					for(int j=i+1;j<=rear;j++)
					{
						if(pq[i].priority>pq[j].priority)
						{
							temp=pq[i];
							pq[i]=pq[j];
							pq[j]=temp;
						}
					}
				}
				cout<<"Element enqueued successfully.\n";
    		}
		}
		void dequeue()
		{
			if(front==-1)	
			{
				cout<<"Queue Underflow!!! Element cant be dequeued.\n";
			}
			else
			{
				cout<<"Dequeued element is "<<pq[front].element <<" & its priority is "<<pq[front].priority;
				for(int i=front;i<=rear;i++)
				{
					pq[i]=pq[i+1];
				}
				if(front==rear)
				{
					front=rear=-1;
				}	
				else
				{
					rear=rear-1;
				}
    		}
		}
		void display()
		{
			if(front==-1)
			{
				cout<<"Priority queue is empty.\n";
			}
			else
			{		
				cout<<"\nQueue Elements :\n";
				cout<<"Element   Priority\n";
				for(int i=front;i<=rear;i++)
				{
					cout<<"   "<<pq[i].element<<"        "<<pq[i].priority<<endl;	
				}
   			}
		}
		void menu()
		{
			do{
				cout<<"\nMenu :\n1.Enqueue\n2.Dequeue\n3.Display\n4.Exit\n";
				cout<<"Enter your choice : ";
				cin>>ch;
				switch(ch)
				{
					case 1:
				  	    enqueue();
				   		break;
					case 2:
				   		dequeue();
				    	break;
					case 3:
			        	display();
			    		break;	
					case 4:
			        	exit(0);
	     			default: 
					cout<<"Invalid Choice.\n";
			    }
			}while(1);
		}
};
int main()
{
	prio_queue q;
	q.initialize();
	q.menu();
	return 0;
}

