#include<iostream>
#include<stdlib.h>
#include<string.h>
using namespace std;
class radix_sort
{
	public:
		int n,*arr,max,len,pass=0;
		string temp[10][10],arr_str[10];
		
		void initialize()
		{
			cout<<endl<<"Enter number of elements to be sorted : ";
			cin>>n;
			arr=(int*)malloc(n*sizeof(int));
			cout<<endl<<"Enter "<<n<<" elements :"<<endl;
			for(int i=0;i<n;i++)
			{
				cin>>arr[i];
			}
		}
		void sort()
		{
			//Initializing buckets to null
			
			for(int i=0;i<10;i++)
			{
				for(int j=0;j<n;j++)
				{
					temp[i][j]="null";
				}
			}

			//calculate max no. of digits from input
			
			max=arr[0];
			for(int i=0;i<n;i++)
			{
				if(arr[i]>max)
				{
					max=arr[i];
				}	
			}
			string str_max=to_string(max);
			len=str_max.length();
		
			//copying input array to string array by converting integer value to string value
			
			for(int i=0;i<n;i++)
			{
				string str=to_string(arr[i]);
				arr_str[i]=str;
			}
						
			//attaching 0 to some elements to make all elements of same no. of digits
			
			for(int i=0;i<n;i++)
			{
				int ele_len=arr_str[i].length();
				while(ele_len%len!=0)
				{
					arr_str[i]="0"+arr_str[i];
					ele_len++;
				}
			}
		
			cout<<endl<<"Pass "<<pass<<" :";
			for(int p=0;p<n;p++)
			{
				cout<<"   "<<stoi(arr_str[p]);
			}
			cout<<endl;
			
			for(int i=len-1;i>=0;i--)
			{
				for(int j=0;j<n;j++)
				{
					string dig=arr_str[j].substr(i,1);
					switch(stoi(dig))
					{
						case 0:
							for(int k=0;k<n;k++)
							{
								if(temp[0][k]=="null")
								{
									temp[0][k]=arr_str[j];
									break;
								}	
							}
							break;
						case 1:
							for(int k=0;k<n;k++)
							{
								if(temp[1][k]=="null")
								{
									temp[1][k]=arr_str[j];
									break;
								}	
							}
							break;
						case 2:
							for(int k=0;k<n;k++)
							{
								if(temp[2][k]=="null")
								{
									temp[2][k]=arr_str[j];
									break;
								}	
							}
							break;
						case 3:
							for(int k=0;k<n;k++)
							{
								if(temp[3][k]=="null")
								{
									temp[3][k]=arr_str[j];
									break;
								}	
							}
							break;
						case 4:
							for(int k=0;k<n;k++)
							{
								if(temp[4][k]=="null")
								{
									temp[4][k]=arr_str[j];
									break;
								}	
							}
							break;
						case 5:
							for(int k=0;k<n;k++)
							{
								if(temp[5][k]=="null")
								{
									temp[5][k]=arr_str[j];
									break;
								}	
							}
							break;
						case 6:
							for(int k=0;k<n;k++)
							{
								if(temp[6][k]=="null")
								{
									temp[6][k]=arr_str[j];
									break;
								}	
							}
							break;
						case 7:
							for(int k=0;k<n;k++)
							{
								if(temp[7][k]=="null")
								{
									temp[7][k]=arr_str[j];
									break;
								}	
							}
							break;
						case 8:
							for(int k=0;k<n;k++)
							{
								if(temp[8][k]=="null")
								{
									temp[8][k]=arr_str[j];
									break;
								}	
							}
							break;
						case 9:
							for(int k=0;k<n;k++)
							{
								if(temp[9][k]=="null")
								{
									temp[9][k]=arr_str[j];
									break;
								}	
							}
							break;
						default:
							exit(0);
					}
				}				
				int m=0;
				for(int k=0;k<10;k++)
				{
					for(int l=0;l<n;l++)
					{
						if(temp[k][l]!="null")
						{
							arr_str[m]=temp[k][l];
							m++;
						}
					}
				}
				pass++;
				cout<<endl<<"Pass "<<pass<<" :";
				for(int p=0;p<n;p++)
				{
					cout<<"   "<<stoi(arr_str[p]);
				}
				cout<<endl;
				
				for(int i=0;i<10;i++)
				{
					for(int j=0;j<n;j++)
					{
						temp[i][j]="null";
					}
				}
		    }						
		}
};
int main()
{
	radix_sort rs1;
	rs1.initialize();
	rs1.sort();
	return 0;
}
