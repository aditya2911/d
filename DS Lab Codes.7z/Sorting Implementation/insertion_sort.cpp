#include<iostream>
#include<stdlib.h>
using namespace std; 
class ins_sort
{
	public:
		int n,ch,*arr,pass,key;
		void initialize()
		{
			cout<<endl<<"Enter number of elements to be sorted : ";
			cin>>n;
			arr = (int*) malloc(n*sizeof(int));
			cout<<endl<<"Enter "<<n<<" elements : "<<endl;
			for(int i=0;i<n;i++)
			{
				cin>>arr[i];
			}
		}
		void sort()
		{  
			pass=0;
			cout<<endl<<"Pass "<<pass<<" :";
			for(int i=0;i<n;i++)
			{					
				cout<<"    "<<arr[i];
			}
			cout<<endl;
			for(int i=1;i<n;i++)
			{
				key=arr[i];
				int j=i-1;
				while(j>=0 && arr[j]>key)
				{
					arr[j+1]=arr[j];	
					j--;					
				}
				arr[j+1]=key;
				
				pass++;
				cout<<endl<<"Pass "<<pass<<" :";
				for(int k=0;k<=i;k++)
				{					
					cout<<"    "<<arr[k];	
				}
				cout<<endl;					
			}  
		}
	
};
int main()
{
	ins_sort i1;
	i1.initialize();
	i1.sort();
}
