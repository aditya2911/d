#include<iostream>
#include<stdlib.h>
using namespace std;
class quick_sort 
{
	public:
	int n,*arr,i,j;
	quick_sort()
	{
		cout<<endl<<"Enter number of elements : ";
		cin>>n;
		arr=(int*)malloc(n*sizeof(int));
		cout<<endl<<"Enter "<<n<<" elements : "<<endl;
		for(int i=0;i<n;i++)
		{
			cin>>arr[i];
		}
		sort(arr, 0, n-1);
	}	
	void sort(int arr[],int i,int j)
	{
		if(i<j)
		{
			int loc = getPivotLoc(arr, i, j);
			sort(arr, i, loc-1);
			sort(arr, loc+1, j);
		}      
	}
	int getPivotLoc(int arr[],int i,int j)
	{
		int low_pos = i;
		int high_pos = j;
		int pivot = arr[i];
		while(low_pos<high_pos){
			while(arr[low_pos]<=pivot){
				low_pos++;
			}
				while(arr[high_pos]>pivot){
					high_pos--;
				}
				if(low_pos<high_pos){
					int temp = arr[low_pos];
					arr[low_pos] = arr[high_pos];
					arr[high_pos] = temp;
				}	
			}
			int temp = arr[high_pos];
			arr[high_pos] = pivot;
			arr[i]=temp;
			return high_pos;		
	}
	void display()
	{
		cout<<endl<<"Sorted Array :";
		for(int i=0;i<n;i++)
		{
			cout<<"   "<<arr[i];
		}
	}
};
int main()
{
	quick_sort qs1;
	qs1.display();
	return 0;
}
