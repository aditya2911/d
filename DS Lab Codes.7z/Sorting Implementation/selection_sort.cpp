#include<iostream>
#include<stdlib.h>
using namespace std; 
class sel_sort
{
	public:
		int n,ch,*arr,loc,pass,max;
		void initialize()
		{
			cout<<endl<<"Enter number of elements to be sorted : ";
			cin>>n;
			arr = (int*) malloc(n*sizeof(int));
			cout<<endl<<"Enter "<<n<<" elements : "<<endl;
			for(int i=0;i<n;i++)
			{
				cin>>arr[i];
			}
		}
		void sort()
		{ 
			pass=0;
			cout<<endl<<"Pass "<<pass<<" :";
			for(int i=0;i<n;i++)
			{					
				cout<<"    "<<arr[i];	
			}
			cout<<endl;
			for(int i=n-1;i>=0;i--)
			{
				max=arr[i];
				loc=i;
				for(int j=i-1;j>=0;j--)
				{
					if(arr[j]>max)
					{
						max= arr[j];
						loc=j;						
					}
				}
				if(loc!=i)
				{
					int temp=arr[i];
					arr[i]=arr[loc];
					arr[loc]=temp;					
				}
				pass++;
				if(pass<n)
				{
					cout<<endl<<"Pass "<<pass<<" :";
					for(int k=0;k<n;k++)
					{					
						cout<<"    "<<arr[k];	
					}
					cout<<endl;					
				}
			}  
		}
	
};
int main()
{
	sel_sort s1;
	s1.initialize();
	s1.sort();
}
