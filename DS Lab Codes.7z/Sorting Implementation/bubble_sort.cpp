#include<iostream>
#include<stdlib.h>
using namespace std; 
class bubble_sort
{
	public:
		int n,ch,*arr,pass;
		void initialize()
		{
			cout<<endl<<"Enter number of elements to be sorted : ";
			cin>>n;
			arr = (int*) malloc(n*sizeof(int));
			cout<<endl<<"Enter "<<n<<" elements : "<<endl;
			for(int i=0;i<n;i++)
			{
				cin>>arr[i];
			}
		}
		void sort()
		{  
			pass=0;
			cout<<endl<<"Pass "<<pass<<" :";
			for(int i=0;i<n;i++)
			{					
				cout<<"    "<<arr[i];	
			}
			cout<<endl;
			for(int i=0;i<n-1;i++)
			{
				for(int j=0;j<n-1;j++)
				{
					if(arr[j]>arr[j+1])
					{
						int temp= arr[j];
						arr[j]=arr[j+1];
						arr[j+1]=temp;						
					}
				}
				pass++;
				cout<<endl<<"Pass "<<pass<<" :";
				for(int i=0;i<n;i++)
				{					
					cout<<"    "<<arr[i];	
				}
				cout<<endl;					
			}  
		}
	
};
int main()
{
	bubble_sort b1;
	b1.initialize();
	b1.sort();
}
