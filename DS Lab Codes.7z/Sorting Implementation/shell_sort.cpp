#include<iostream>
#include<stdlib.h>
using namespace std;
class shell_sort 
{
	public:
	int n,*arr,interval,pass=0;
	void initialize()
	{
		cout<<endl<<"Enter number of elements : ";
		cin>>n;
		arr=(int*)malloc(n*sizeof(int));
		cout<<endl<<"Enter "<<n<<" elements : "<<endl;
		for(int i=0;i<n;i++)
		{
			cin>>arr[i];
		}
	}	
	void sort()
	{
		cout<<endl<<"Pass "<<pass<<" :";
		for(int i=0;i<n;i++)
		{
			cout<<"   "<<arr[i];
		}
		cout<<endl;
		for(interval=n/2; interval>0; interval=interval/2){
			for(int j=interval; j<n; j++){
				for(int i=j-interval; i>=0; i=i-interval ){
					if(arr[i+interval]<=arr[i]){
						int temp = arr[i];
						arr[i]=arr[i+interval];
						arr[i+interval]=temp;
					}
					else{
						break;
					}	
				}
			}
			pass++;
			cout<<endl<<"Pass "<<pass<<" :";
			for(int k=0;k<n;k++)
			{
				cout<<"   "<<arr[k];
			}
			cout<<endl;
		}
	
	}
};
int main()
{
	shell_sort ss1;
	ss1.initialize();
	ss1.sort();
	return 0;
}


