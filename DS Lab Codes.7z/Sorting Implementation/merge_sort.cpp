#include<iostream>
#include<stdlib.h>
using namespace std;
class merge_sort 
{
	public:
	int n,*arr,i,j,k;
	merge_sort()
	{
		cout<<endl<<"Enter number of elements : ";
		cin>>n;
		arr=(int*)malloc(n*sizeof(int));
		cout<<endl<<"Enter "<<n<<" elements : "<<endl;
		for(int i=0;i<n;i++)
		{
			cin>>arr[i];
		}
		sort(arr,0,n-1,n);
	}	
	void sort(int num_arr[],int lb,int ub,int size)
	{
		int mid;
		if(lb<ub)
		{
			mid=(lb+ub)/2;
			sort(num_arr,lb,mid,size);
			sort(num_arr,mid+1,ub,size);
			merge(num_arr,lb,mid,ub,size);
		}
	}
	void merge(int num_arr[],int lb,int mid,int ub,int size)
	{
		int sorted_arr[size];
		i=lb;
		j=mid+1;
		k=lb;
		while(i<=mid && j<=ub)
		{
			if(num_arr[i]<=num_arr[j])
			{
				sorted_arr[k]=num_arr[i];
				i++;
			}	
			else
			{
				sorted_arr[k]=num_arr[j];
				j++;
			}
			k++;
		}
		if(i>mid)
		{
			while(j<=ub)
			{
				sorted_arr[k]=num_arr[j];
				j++;
				k++;
			}
		}
		else
		{
			while(i<=mid)
			{
				sorted_arr[k]=num_arr[i];
				i++;
				k++;
			}
		}
		for(int m=lb;m<=ub;m++)
		{
			num_arr[m]=sorted_arr[m];
		}
	}
	void display()
	{
		cout<<endl<<"Sorted Array :";
		for(int i=0;i<n;i++)
		{
			cout<<"   "<<arr[i];
		}
	}
};
int main()
{
	merge_sort ms1;
	ms1.display();
	return 0;
}
