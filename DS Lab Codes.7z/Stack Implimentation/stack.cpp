#include<iostream>
using namespace std;
int stk[50],top,size,ch;
class stack
{
	public :
		void initialize()
		{	
			top=-1;
			cout<<"Enter Size of Stack : ";
			cin>>size;
		}
		void menu()
		{
			do
			{
				cout<<"\nMenu :\n1.Push\n2.Pop\n3.Display\n4.Exit\n";
				cout<<"Enter choice : ";
				cin>>ch;
				switch(ch)
				{
					case 1:
						push();
						break;
					case 2:
						pop();
						break;
					case 3:
						display();
						break;
					case 4:
						exit(0);
					default:
						cout<<"Invalid choice.";
				}
			}while(1);
		}
		void push()
		{
			if(top<(size-1))
			{
				top=top+1;
				cout<<"Enter Element : ";
				cin>>stk[top];
				cout<<"Element inserted successfully.\n";
			}
			else
			{
					cout<<"Stack Overflow!!! Element can't be inserted.\n";
			}
			return;	//remove 
		}
		void pop()
		{
			if(top==-1)
			{
				cout<<"Stack Underflow!!! Element can't be deleted.\n";
			}
			else
			{
				top=top-1;
				cout<<"Element deleted successfully.\n";
			}
			return;	
		}
		void display()
		{
			if(top==-1)
			{
				cout<<"Stack is empty.\n";
			}
			else
			{
				cout<<"Elements in stack : ";
				for(int i=top;i>=0;i--)
				{
					cout<<stk[i]<<" ";
				}
				cout<<endl;
			}
			return;
		}		
};
int main()
{
	stack s;
	s.initialize();
	s.menu();
	return 0;
}
