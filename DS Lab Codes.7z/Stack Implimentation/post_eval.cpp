#include<iostream>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>
#define MAX 50
using namespace std;
char P[MAX];
int stk[MAX];
int top;
class stack
{
	public:
		void initialize()
		{
			top=-1;
			cout<<"Enter Postfix Expression :\n";
			cin>>P;
			strcat(P,")");
		}
		void push(int item)
		{
			if(top<=(MAX-1))
			{
				top=top+1;
				stk[top]=item;
			}
			else
			{
					cout<<"Stack Overflow!!!\n";
			}
			return;	
		}
		int pop()
		{
			int item;
			if(top==-1)
			{
				cout<<"Stack Underflow!!! Invalid Exression.\n";
				exit(0);
			}
			else
			{
				item=stk[top];
				top=top-1;
				return (item);
			}
		}
		void Post_Eval()
		{
			int opr1,opr2,res;
			for(int i=0;P[i]!=')';i++)
			{
				if(P[i]==',')
				{
					continue;
				}
				else if(isdigit(P[i]))
				{
					int num=0;
					while(isdigit(P[i]))
					{
						num=(num * 10) + (int)(P[i] - '0');
						i++;
					}
					i--;
					push(num);
		 		}
				else
				{
					opr1=pop();
					opr2=pop();
					switch (P[i]) 
          		  	{
          		  		case '^':
                			res=opr2^opr1;
                			break;
            			case '*':
                			res=opr2*opr1;
                			break;
			            case '/':
            			    res=opr2/opr1;
                			break;
				        case '+':
                			res=opr2+opr1;
                			break;
			            case '-':
            			    res=opr2-opr1;
                			break;
                		default:
                			cout<<"\nInvalid Expression.\n";
           			}
           			push(res);
				}
			}
			cout<<"\nResult of postfix expression evaluation : "<<pop();
		}
};
int main()
{
	stack s;
	s.initialize();
	s.Post_Eval();
	return 0;
}
