#include<iostream>
#include<string.h>
using namespace std;
char str[50],stk[50];
int top,size;
class stack
{
	public:
		void initialize()
		{
			top=-1;
			cout<<"Enter Expression :\n";
			cin>>str;
			size=strlen(str);
		}
		void push(char item)
		{
			if(top<(size-1))
			{
				top=top+1;
				stk[top]=item;
			}
			else
			{
					cout<<"Stack Overflow!!!\n";
			}
		}
		void pop()
		{
			if(top==-1)
			{
				cout<<"Stack Underflow!!! Invalid Exression.\n";
				exit(0);
			}
			else
			{
				top=top-1;
			}
		}
		bool isEmpty()
		{
			if(top==-1)
			{
				return 0;
			}
		}
		void isValid()
		{
			for(int i=0;i<size;i++)
			{
				if(str[0]==')')
				{
					cout<<"Invalid Expression.";
					exit(0);
				}
				if(str[i]=='(')
				{
					push(str[i]);
				}	
				if(str[i]==')')
				{
					pop();
				}
			}
			if(isEmpty()==0)
			{
				cout<<"Valid Expression.";
			}
			else
			{
				cout<<"Invalid Expression.";
			}
		}
};
int main()
{
	stack s;
	s.initialize();
	s.isValid();
	return 0;
}
