#include<iostream>
#include<string.h>
#include<ctype.h>
using namespace std;
char Q[50],P[50],stk[50];
int top,size;
class stack
{
		public:
		void initialize()
		{
			top=-1;
			cout<<"Enter Infix Expression :\n";
			cin>>Q;
			size=strlen(Q);
		}
		void push(char item)
		{
			if(top<(size-1))
			{
				top=top+1;
				stk[top]=item;
			}
			else
			{
				cout<<"Stack Overflow!!!\n";
			}
			return;	
		}
		char pop()
		{
			char item;
			if(top==-1)
			{
				cout<<"Stack Underflow!!! Invalid Exression.\n";
				exit(0);
			}
			else
			{
				item=stk[top];
				top=top-1;
				return (item);
			}
		}
		bool check_opr(char symbol)
		{
			if(symbol == '^' || symbol == '*' || symbol == '/' || symbol == '+' || symbol =='-')
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
		int op_Precedence(char symbol)
		{
			if(symbol == '^')
			{
				return(3);
			}
			else if(symbol == '*' || symbol == '/')
			{
				return(2);
			}
			else if(symbol == '+' || symbol == '-')          
			{
				return(1);
			}
			else
			{
				return(0);
			}
		}
		void In_To_Post(char In_exp[],char Post_exp[])
		{
			int i=0,j=0;
			char item,opr;
			push('(');
			strcat(In_exp,")");
			item=In_exp[i];
			while(item !='\0')
			{
				if(item=='(')
				{
					push(item);
				}
				else if(isdigit(item) || isalpha(item))
				{
					Post_exp[j]=item;
					j++;
				}
				else if(check_opr(item)==1)
				{
					opr=pop();
					while(check_opr(opr) == 1 && op_Precedence(opr)>= op_Precedence(item))
					{
						Post_exp[j] = opr;                 
						j++;
						opr = pop();                      
					}
					push(opr);
					push(item);
				}
				else if(item == ')')         
				{
					opr = pop();                   
					while(opr != '(')               
					{
						Post_exp[j] = opr;
						j++;
						opr = pop();
					}
				}
				else
				{
					cout<<"Invalid Exression.\n";
					exit(0);
				}
				i++;
				item=In_exp[i];
			}
			if(top>0)
			{
				cout<<"Invalid Exression.\n";
				exit(0);
			}
			Post_exp[j]='\0';
			display(Post_exp);
		}
		void display(char expr[])
		{
			cout<<"\nPostfix Expression is : "<<expr;
		}
};
int main()
{
	stack s;
	s.initialize();
	s.In_To_Post(Q,P);
	return 0;
}
