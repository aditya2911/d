#include<iostream>
using namespace std; 
class heap_sort
{
	public:
		int size,*arr,pass=1;
		void initialize()
		{
			cout<<endl<<"Enter number of elements to be sorted : ";
			cin>>size;
			arr = (int*) malloc(size*sizeof(int));
			cout<<endl<<"Enter "<<size<<" elements : "<<endl;
			for(int i=1;i<=size;i++)
			{
				cin>>arr[i];
			}
			sort(arr,size);
		}
		void heapify(int A[],int n,int i)
		{
			int largest=i;
			int left=(2*i);
			int right=(2*i)+1;
			if(left<=n && A[left]>A[largest])
			{
				largest=left;
			}
			if(right<=n && A[right]>A[largest])
			{
				largest=right;
			}
			if(largest!=i)
			{
				int temp=A[largest];
				A[largest]=A[i];
				A[i]=temp;
				heapify(A,n,largest);
			}
		}
		void sort(int A[],int n)
		{  
			for(int i=n/2;i>=1;i--)
			{
				heapify(A,n,i);
			}
			cout<<endl<<"MaxHeap Tree Elements :";
			display();
			for(int i=n;i>=1;i--)
			{
				int temp=A[1];
				A[1]=A[i];
				A[i]=temp;
				heapify(A,i-1,1);
				cout<<endl<<"Pass "<<pass<<" :";
				pass++;
				display();
			}
		}
		void display()
		{
			for(int i=1;i<=size;i++)
			{
				cout<<"  "<<arr[i];
			}
			cout<<endl;	
		}
	
};
int main()
{
	heap_sort hs1;
	hs1.initialize();
	cout<<endl<<"Sorted Tree Elements :";
	hs1.display();
	return (0);
}
