#include<iostream>
#include<stdlib.h>
using namespace std; 
class warshall
{
	public:
		int n,mularr[20][20],inf=9999;
		void initialize()
		{
			cout<<endl<<"Enter number of nodes : ";
			cin>>n;
			for(int i=0;i<n;i++)
			{
				for(int j=0;j<n;j++)
				{	
					mularr[i][j]=inf;
				}
			}
			cout<<endl<<"If there is a distance present between given 2 nodes, then enter distance otherwise enter 0"<<endl ;
			for(int i=0;i<n;i++)
			{
				char from=65+i;
				for(int j=0;j<n;j++)
				{
					char to=65+j;
					if(i==j)
					{
						mularr[i][j]=0;
					}
					else
					{	
						int inp;
						cout<<endl<<"Distance between "<<from<<" - "<<to<<" : ";
						cin>>inp;
						if(inp==0)
						{
							mularr[i][j]=inf;
							mularr[j][i]=inf;
						}
						else
						{
							mularr[i][j]=inp;
							mularr[j][i]=inp;
						}
					}
				}
			}
		}
		
		void applyWarshall()
		{
			for(int k=0;k<n;k++)
			{
				for(int i=0;i<n;i++)
				{
					for(int j=0;j<n;j++)
					{
						if((mularr[i][k]+mularr[k][j])<mularr[i][j])
						{
							mularr[i][j]=mularr[i][k]+mularr[k][j];
						}
					}
				}
				char str=65+k;
				cout<<endl<<"Consider "<<str<<" as intermediartory node, we get "<<endl;
				display();
			}
		}
		void display()
		{
			for(int i=0;i<n;i++)
			{
				for(int j=0;j<n;j++)
				{
					cout<<mularr[i][j]<<"   ";
				}
				cout<<endl;
			}
		}
};
int main()
{
	warshall w1;
	w1.initialize();
	w1.applyWarshall();
	cout<<endl<<"Shortest Path Matrix :"<<endl;
	w1.display();
	return (0);
}
