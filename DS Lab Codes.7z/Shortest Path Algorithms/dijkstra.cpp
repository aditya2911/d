#include<iostream>
#include<stdlib.h>
using namespace std; 
class dijkstra
{
	public:
		int n,mularr[20][20],*dist,sourceNode,destNode,flag1,flag2,m,*prevNode,inf=999;
		char srcInp,destInp,*nodes,*path;
		bool *visited;
		void initialize()
		{
			cout<<endl<<"Enter number of nodes : ";
			cin>>n;
			cout<<endl<<"If there is a distance present between given 2 nodes, then enter distance otherwise enter 0"<<endl ;
			for(int i=0;i<n;i++)
			{
				char from=65+i;
				for(int j=0;j<n;j++)
				{
					char to=65+j;
					if(i==j)
					{
						mularr[i][j]=0;
					}
					else
					{	
						int inp;
						cout<<endl<<"Distance between "<<from<<" - "<<to<<" : ";
						cin>>inp;
						if(inp==0)
						{
							mularr[i][j]=inf;
							mularr[j][i]=inf;
						}
						else
						{
							mularr[i][j]=inp;
							mularr[j][i]=inp;
						}
					}
				}
			}
		}
		void calShortDist()
		{
			dist=new int[n];
			visited= new bool[n];
			nodes=new char[n];
			prevNode=new int[n];
			path=new char[n];
			for(int i=0;i<n;i++)
			{
				dist[i]=inf;
				visited[i]=false;
				nodes[i]=65+i;
			}
            nodeSelection: 	
			flag1=0,flag2=0;
			cout<<endl<<"Choose source node (";
			for(int i=0;i<n;i++)
			{
				cout<<" "<<nodes[i];
			}
			cout<<" ) : ";
			cin>>srcInp;
			cout<<endl<<"Choose destination node (";
			for(int i=0;i<n;i++)
			{
				cout<<" "<<nodes[i];
			}
			cout<<" ) : ";
			cin>>destInp;
			for(int i=0;i<n;i++)
			{
				if(int(srcInp)==65+i)
				{
					sourceNode=i;
					flag1=1;
				}
			}
			for(int i=0;i<n;i++)
			{
				if(int(destInp)==65+i)
				{
					destNode=i;
					flag2=1;
				}
			}
			if(flag1==1 && flag2==1)
			{
				for(int i=0;i<n;i++)
				{
					prevNode[i]=sourceNode;
					path[i]='#';
				}
				dist[sourceNode] = 0;         
				for(int i = 0; i<n; i++)                           
				{
					int min=inf,m;
        			for(int i=0;i<n;i++) 
					{
						if(visited[i]==false && dist[i]<=min)      
						{
							min=dist[i];
							m=i;
						}
					} 
					visited[m]=true;
					for(int i = 0; i<n;i++)                   
					{
						if(visited[i]==false && mularr[m][i]!=0)
						{
							if(dist[m]+mularr[m][i]<dist[i])
							{ 
								dist[i]=dist[m]+mularr[m][i];
								prevNode[i]=m;
							}
						}
					}
				}
				cout<<endl<<"Shortest Distance from "<<srcInp<<" to "<<destInp<<" : "<<dist[destNode]<<endl;	
				
				if(destNode!=sourceNode)
				{
				    path[0]=destInp;
				    int j=destNode;
				    int k=1;
				    do {
				        j=prevNode[j];
				        path[k]=j+65;
				        k++;
				    }while(j!=sourceNode);
				}
				cout<<endl<<"Shortest Distance from "<<srcInp<<" to "<<destInp<<" :  "<<srcInp;
				for(int i=n-1;i>=0;i--)
				{
					if(path[i]!='#' && path[i]!=srcInp)
					{						
					    cout<<" --> "<<path[i];
					}
				}
			}
			else
			{
				cout<<endl<<"You entered wrong nodes.\nPlease choose nodes from given nodes";
				goto nodeSelection;
			}
		}
};
int main()
{
	dijkstra d1;
	d1.initialize();
	d1.calShortDist();
	return (0);
}
