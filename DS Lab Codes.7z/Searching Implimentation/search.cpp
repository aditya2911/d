#include<iostream>
using namespace std;
class search
{
    int arr[10],key,flag,pos,n,temp,low,mid,high,ch;
    public:
        void initialize()
        {
        	cout<<"\nHow many elements you want to enter?\n";
    		cin>>n;
    		cout<<"\nEnter elements :"<<endl;
   	 	    for(int i=0;i<n;i++)
    		{
        		cin>>arr[i];
    		}
		}
		void menu()
		{
			for(int i=0;i<n;i++)
			{
				for(int j=i+1;j<n;j++)
				{
					if(arr[i]==arr[j])
					{
						cout<<endl<<"Duplicate elements are present in given data.\n";
						exit(0);
					}
				}
			}
			do{
				cout<<"\nMenu :\n1.Linear or Linear Sequential Search\n2.Binary Search\n3.Display the elements\n4.Exit\n";
				cout<<"Enter your choice : ";
				cin>>ch;
				switch(ch)
				{
					case 1:
				  	    lsearch();
				   		break;
					case 2:
				   		bsearch();
				    	break;
					case 3:
			        	display();
			    		break;	
					case 4:
			        	exit(0);
	     			default:
					cout<<"Invalid Choice.\n";
			    }
			}while(1);	
		}
        void lsearch()
        {
        	cout<<"\nEnter element to be searched :\n";
			cin>>key;
			flag=0;
			for(int i=0;i<n;i++)
			{
	    		if(arr[i]==key)
	    		{
	        		flag=1;
	        		pos=i;
	        		break;
	    		}
			}
			if(flag==1)
			{
	   			cout<<endl<<key<<" is found at position "<<pos+1<<" (i.e. Index no. "<<pos<<").\n";
			}
			else
			{
		    	cout<<endl<<key<<" is not found.\n";
			}     	
		}
		void bsearch()
		{
			for(int i=0;i<n;i++)
			{
				for(int j=i+1;j<n;j++)
				{
					if(arr[i]>arr[j])
					{
						temp=arr[i];
						arr[i]=arr[j];
						arr[j]=temp;
					}
				}
			}
		    cout<<"\nEnter element to be searched :\n";
	    	cin>>key;
   	    	low=0;
    		high=n-1;
    		mid=(low+high)/2;
  	  		while((key!=arr[mid])&&low<high)
    		{
       	 		if(key<arr[mid])
        		{
            		high=mid-1;
        		}
        		else
        		{
            		low=mid+1;
        		}
        		mid=(low+high)/2;
    		}
    		if(key==arr[mid])
    		{
        		cout<<endl<<key<<" is found at position "<<mid+1<<" (i.e. Index no. "<<mid<<").\n";
			}
			else
			{
		    	cout<<endl<<key<<" is not found.\n";
    		}
		}
		void display()
		{
			cout<<endl<<"Given elements are : ";
			for(int i=0;i<n;i++)
    		{
        		cout<<"  "<<arr[i];
    		}
    		cout<<endl;
		}
};
int main()
{
    search s;
    s.initialize();
    s.menu();
    return 0;
}

