#include<iostream>
using namespace std; 
class graph_traversal
{
	public:
		int n,ch,mularr[20][20],*stk,top,*que,front,rear,s,
		flag;
		void initialize()
		{
			cout<<endl<<"Enter number of nodes : ";
			cin>>n;
			cout<<endl<<"If there is an edge is present between given 2 nodes, then enter 1 otherwise enter 0"<<endl ;
			for(int i=0;i<n;i++)
			{
				for(int j=0;j<n;j++)
				{
					cout<<endl<<"Edge between "<<i<<" - "<<j<<" : ";
					cin>>mularr[i][j];
				}
			}
			cout<<endl<<"Adjacency matrix for the given graph :"<<endl;
			for(int i=0;i<n;i++)
			{
				for(int j=0;j<n;j++)
				{
					cout<<mularr[i][j]<<"   ";
				}
				cout<<endl;
			}
		}
		void menu()
		{
			do{
				cout<<"\nMenu :\n1.Breadth First Search\n2.Depth First Search\n3.Exit";
				cout<<endl<<"Enter your choice : ";
				cin>>ch;
				switch(ch)
				{
					case 1:
				   		getBFS();
				    	break;
					case 2:
			        	getDFS();
			    		break;	
					case 3:
			        	exit(0);
	     			default:
					cout<<"Invalid Choice.\n";
			    }
			}while(1);	
		}
		void getBFS()
		{
			front=0,rear=-1;
			que=new int[n];
			bool *visited= new bool[n];
			for(int i=0;i<n;i++)
			{
				visited[i]=false;
			}
			rear++;
			que[rear]=0;
			cout<<endl<<"BFS Sequence for given graph :";
			while(front<=rear)
			{
				s=que[front];
				visited[s]=true;
				cout<<" --> "<<s;
				front++;
				for(int i=0;i<n;i++)
				{
					if(mularr[s][i]==1 && visited[i]==false)
					{
						flag=0;
						for(int j=front;j<=rear;j++)
						{
							if(i ==que[j]) 
							{
								flag=1;
								break;
							}
						}
						if(flag==0)
						{
							rear++;
						   	que[rear]=i;									
						}
					}
				}
			}
		}	
		void getDFS()
		{
			top=0;
			stk=new int[n];
			bool *visit= new bool[n];
			bool *visited= new bool[n];
			for(int i=0;i<n;i++)
			{
				visit[i]=false;
				visited[i]=false;
			}
			s=0;
			visited[s]=true;
			cout<<endl<<"DFS Sequence for given graph : ";
			cout<<s;
   			int k=1;
	    	while(k<n)
			{
				for(int j=n-1; j>=0; j--)
				{
					if(mularr[s][j]==1 && visited[j]==false && visit[j]==false)
            		{
               	    	visit[j]=true;
                		stk[top]=j;
                		top++;
            		}
				}            		
        		s=stk[--top];
        		cout<<" --> "<<s;
       			k++;
       			visit[s]=false;
       			visited[s]=true;
    		}	
		}
};
int main()
{
	graph_traversal gt1;
	gt1.initialize();
	gt1.menu();
}
