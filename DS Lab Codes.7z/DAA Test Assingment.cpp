#include <iostream>
using namespace std;
// stores adjacency list items
struct adjNode {
    int val, cost;
    adjNode* next;
};
struct graphEdge {
    int start_ver, end_ver, weight;
};
class DiaGraph{
	
    adjNode* getAdjListNode(int value, int weight, adjNode* head)   {
        adjNode* newNode = new adjNode;
        newNode->val = value;
        newNode->cost = weight;
         
        newNode->next = head;   
        return newNode;
    }
    int N;  
public:
    adjNode **head;                
    DiaGraph(graphEdge edges[], int n, int N)  {
        
        head = new adjNode*[N]();
        this->N = N;
        
        for (int i = 0; i < N; ++i)
            head[i] = nullptr;
        
        for (unsigned i = 0; i < n; i++)  {
            int start_ver = edges[i].start_ver;
            int end_ver = edges[i].end_ver;
            int weight = edges[i].weight;
            // insert in the beginning
            adjNode* newNode = getAdjListNode(end_ver, weight, head[start_ver]);
             
                        // point head pointer to new node
            head[start_ver] = newNode;
             }
    }
      // Destructor
     ~DiaGraph() {
    for (int i = 0; i < N; i++)
        delete[] head[i];
        delete[] head;
     }
};
// print all adjacent vertices of given vertex
void display_AdjList(adjNode* ptr, int i)
{
    while (ptr != nullptr) {
        cout << "(" << (char)(65+i) << ", " << (char)(65+ptr->val)
            << ", " << ptr->cost << ") ";
        ptr = ptr->next;
    }
    cout << endl;
}
// graph implementation
int main()
{
	int N;
    // graph edges array.
    graphEdge edges[] = {
        // (x, y, w) -> edge from x to y with weight w
        {0,1,2},{0,3,2},{0,2,4},{1,4,3},{2,3,2},{3,1,4},{4,3,3}
    };
    cout<<"Enter no. of vertices : ";
    cin>>N;      // Number of vertices in the graph
    // calculate number of edges
    
	int n = sizeof(edges)/sizeof(edges[0]);
  
    // construct graph
    DiaGraph diagraph(edges, n, N);
    // print adjacency list representation of graph
    cout<<"Graph adjacency list "<<endl<<"(start_vertex, end_vertex, weight):"<<endl;
    for (int i = 0; i < N; i++)
    {
        // display adjacent vertices of vertex i
        display_AdjList(diagraph.head[i], i);
    }
    return 0;
}
