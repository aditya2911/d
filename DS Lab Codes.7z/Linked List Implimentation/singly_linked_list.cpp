#include<iostream>
#include<stdlib.h>
using namespace std;
struct node
{
	int data;
	struct node *next;
};
class singly_list
{
	public:
		struct node *list=NULL ,*p,*q,*r;
		int value,ch,key,counter;
		void insert_begin()
		{
			p=(struct node*)malloc(sizeof(node));
			cout<<endl<<"Enter data that you want to insert : ";
			cin>>value;
			p->data=value;
			if(list==NULL)
			{
				p->next=NULL;
				list=p;
			}
			else
			{
				p->next=list;
				list=p;
			}
			cout<<endl<<value<<" inserted successfully.";	
		}
		void insert_end()
		{
			p=(struct node*)malloc(sizeof(node));
			cout<<endl<<"Enter data that you want to insert : ";
			cin>>value;
			p->data=value;
			if(list==NULL)
			{
				p->next=NULL;
				list=p;
			}
			else
			{
				q=list;
				while(q->next!=NULL)
				{
					q=q->next;
				}
				p->next=NULL;
				q->next=p;
			}
			cout<<endl<<value<<" inserted successfully.";	
		}
		void insert_after()
		{
			if(list==NULL)
			{
				cout<<endl<<"cannot insert anything as list is empty.";	
			}
			else
			{
				cout<<endl<<"Enter data after that you want insert new node : ";
				cin>>key;
				q=list;
				while(q->data!=key && q->next!=NULL)
				{
					q=q->next;
				}
				if(q->data==key)
				{
					p=(struct node*)malloc(sizeof(node));
					cout<<endl<<"Enter data that you want to insert : ";
					cin>>value;
					p->data=value;
					p->next=q->next;
					q->next=p;
					cout<<endl<<value<<" inserted successfully.";
				}
				else
				{
					cout<<endl<<key<<" not found.";
				}
			}
		}
		void insert_before()
		{
			if(list==NULL)
			{
				cout<<endl<<"cannot insert anything as list is empty.";	
			}
			else
			{
				cout<<endl<<"Enter data before that you want insert new node : ";
				cin>>key;
				if(list->data==key)
				{
					insert_begin();
				}
				else
				{
					q=list;
					while(q->next->data!=key && q->next!=NULL)
 					{
						q=q->next;
					}
					if(q->next->data==key)
		 			{
						p=(struct node*)malloc(sizeof(node));
						cout<<endl<<"Enter data that you want to insert : ";
						cin>>value;
						p->data=value;
						p->next=q->next;
						q->next=p;
						cout<<endl<<value<<" inserted successfully.";
					}
					else
					{
						cout<<endl<<key<<" not found.";
					}
				}
			}
		}
		void delete_begin()
		{
			if(list==NULL)
			{
				cout<<endl<<"Cannot delete anything as list is empty.";
			}
			else
			{
				q=list;
				value=q->data;
				list=q->next;
				free(q);
				cout<<endl<<value<<" deleted successfully.";
			}
		}
		void delete_end()
		{
			if(list==NULL)
			{
				cout<<endl<<"Cannot delete anything as list is empty.";
			}
			else
			{
				if(list->next==NULL)
				{
					free(list);
					list=NULL;
				}
				else
				{
					q=list;
					while(q->next!=NULL)
					{
						p=q;
						q=q->next;
					}
					p->next=NULL;
					value=q->data;
					free(q);
					cout<<endl<<value<<" deleted successfully.";
				}
			}
		}
		void delete_node()
		{
			if(list==NULL)
			{
				cout<<endl<<"Cannot delete anything as list is empty.";
			}
			else
			{
				cout<<endl<<"Enter data that you want to delete : ";
				cin>>key;
				if(list->data==key)
				{
					delete_begin();
				}
				else
				{
					q=list;
					while(q->data!=key && q->next!=NULL)
					{
						p=q;
						q=q->next;
					}
					if(q->data==key)
					{
						p->next=q->next;
						free(q);
						cout<<endl<<key<<" deleted successfully.";
					}
					else
					{
						cout<<endl<<key<<" not found.";
					}
				}
			}
		}
		void search()
		{
			if(list==NULL)
			{
				cout<<endl<<"Cannot search anything as list is empty.";
			}
			else
			{
				cout<<endl<<"Enter data that you want to search : ";
				cin>>key;
				counter=0;
				q=list;
				while(q->data!=key && q->next!=NULL)
				{
					counter=counter+1;
					q=q->next;
				}
				if(q->data==key)
				{
					cout<<endl<<key<<" found at position "<<counter;
				}
				else
				{
					cout<<endl<<key<<" not found.";
				}
			}
		}
		void sort()
		{
			if(list==NULL)
			{
				cout<<endl<<"Cannot sort as list is empty.";
			}
			else
			{
				q=list;
				while(q!=NULL)
				{
					r=q->next;
					while(r!=NULL)
					{
						if(q->data>r->data)
						{
							int temp;
							temp=q->data;
							q->data=r->data;
							r->data=temp;
						}
						r=r->next;
					}
					q=q->next;
				}
			}		
		}
		void reverse()
		{
			if(list==NULL)
			{
				cout<<endl<<"Cannot reverse as list is empty.";
			}
			else
			{
				q=list;
				list=NULL;
				while(q!=NULL)
				{
					r=q->next;
					q->next=list;
					list=q;
					q=r;
				}
			}
		}
		void count()
		{
			if(list==NULL)
			{
				cout<<endl<<"Cannot count nodes as list is empty.";
			}
			else
			{
				counter=0;
				q=list;
				while(q!=NULL)
				{
					counter=counter+1;
					q=q->next;
				}
				cout<<endl<<"List Contains "<<counter<<" nodes.";
			}
		}
		void display()
		{
			if(list==NULL)
			{
				cout<<endl<<"List is empty.";	
			}
			else
			{
				cout<<endl<<"List elements are : ";
				q=list;
				while(q!=NULL)
				{
					cout<<q->data<<" ---> ";
					q=q->next;
				}
				cout<<"NULL"<<endl ;
			}
		}
		void menu()
		{
			do{
				cout<<"\n\nMenu :\n";
				cout<<"1.Insertion from beginning\n";
				cout<<"2.Insertion at end\n" ;
				cout<<"3.Insertion after a particular node\n";
				cout<<"4.Insertion before a particular node\n";
				cout<<"5.Deletion from beginning\n";
				cout<<"6.Deletion from end\n";
				cout<<"7.Deletion of a particular node\n";
				cout<<"8.Search a particular node\n";
				cout<<"9.Sort a linked list\n";
				cout<<"10.Reverse a linked list\n";
				cout<<"11.Count total nodes\n";
				cout<<"12.Display\n";
				cout<<"13.Exit\n";
				cout<<"Enter your choice : ";
				cin>>ch;
				switch(ch)
				{
					case 1:
				  	    insert_begin();
				   		break;
					case 2:
						insert_end();
				    	break;
				    case 3:
				    	insert_after();
				    	break;
					case 4:
						insert_before();
						break;
					case 5:
			        	delete_begin();
			    		break;
			    	case 6:
			        	delete_end();
			    		break;
			    	case 7:
			        	delete_node();
			    		break;
			    	case 8:
			        	search();
			    		break;
			    	case 9:
			        	sort();
			    		break;
			    	case 10:
			        	reverse();
			    		break;
			    	case 11:
			        	count();
			    		break;
					case 12:
			        	display();
			    		break;	
					case 13:
			        	exit(0);
	     			default:
					cout<<"Invalid Choice.\n";
			    }
			}while(1);
		}
};
int main()
{ 
	singly_list s;
	s.menu();
	return 0;
}

