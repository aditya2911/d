#include <iostream>
#include <stdlib.h>
#include<bits/stdc++.h>
using namespace std;
struct Tree_Node
{
	int data;
	Tree_Node *left;
	Tree_Node *right;
}*root=NULL,*p=NULL,*q=NULL;
class Binary_Tree
{
	public:
		int size,value,c;
		void create()
		{
			c = 0;
			cout<<endl<<"Enter number of nodes : ";
			cin>>size;
			while (c < size)
			{
				if(root == NULL)
				{
					root = new Tree_Node;
					cout<<endl<<"Enter value of root node : ";
					cin>>root->data;
					root->right=NULL;
					root->left=NULL;
				}
				else
				{
					p = root;
					cout<<endl<<"Enter value of node : ";
					cin>>value;
					while(true)
					{
						if (value < p->data)
						{
							if (p->left == NULL)
							{
								p->left = new Tree_Node;
								p = p->left; 
								p->data = value;
								p->left = NULL;
								p->right = NULL;
								cout<<endl<<value<<" inserted in left.";
								break;
							}
							else if (p->left != NULL)
							{
								p = p->left;
							}
						}
						else if (value > p->data)
						{
							if (p->right == NULL)
							{
								p->right = new Tree_Node;
								p = p->right;
								p->data = value;
								p->left = NULL;
								p->right = NULL;
    							cout<<endl<<value<<" inserted in right.";
								break;
							}
							else if (p->right != NULL)
							{
								p = p->right;
							}
						}
					}
				}
				c++;
			}
			menu(root);
		}
		
		void InOrder(Tree_Node* root)
		{
			if (root == NULL)
			{
				cout<<"Tree is empty!!!!"<<endl;
				return;
			}
			stack<Tree_Node *> stk;
			Tree_Node *node = root;
			cout<<endl<<"In Order :";
			while (node != NULL || stk.empty() == false)
			{ 
				while (node != NULL)
				{
					stk.push(node);
					node = node->left;
				}
				node = stk.top();
				stk.pop();
				cout <<"   "<< node->data;
				node = node->right;
			}
			cout<<endl;
		}
		void PreOrder(Tree_Node* root)
		{
			if (root == NULL)
			{
				cout<<"Tree is empty!!!!"<<endl;
				return; 
			}
			stack<Tree_Node*> st;
			Tree_Node* node = root;
			cout<<endl<<"Pre Order :";
			while (!st.empty() || node != NULL)
			{
				while (node != NULL)
				{
					cout <<"   "<< node->data;
					if (node->right)
					{
						st.push(node->right);
					} 
					node = node->left;
				}
				if (st.empty() == false)
				{
					node = st.top();
					st.pop();
				}
			}
			cout<<endl;
		}
		void PostOrder(Tree_Node* root)
		{
			if (root == NULL)
			{
				cout<<"Tree is empty!!!!"<<endl; 
				return;
			}
			stack<Tree_Node *> stackA, stackB;
			stackA.push(root);
			Tree_Node* node;
			cout<<endl<<"Post Order :";
			while (!stackA.empty())
			{
				node = stackA.top();
				stackA.pop();
				stackB.push(node);
				if (node->left)
				{
					stackA.push(node->left);
				}
				if (node->right)
				{
					stackA.push(node->right);
				}
			}
			while (!stackB.empty())
			{
				node = stackB.top();
				stackB.pop();
				cout <<"   "<< node->data;
			}
			cout<<endl;
		}
		void menu(Tree_Node* root)
		{
			int ch;
			do
			{
				cout<<endl<<"1)InOrder \n2)PreOrder \n3)PostOrder \n4)Exit \nEnter your choice : "<<endl;
				cin>>ch;
				switch(ch)
				{
					case 1:
						InOrder(root);
						break;
					case 2:
						PreOrder(root);
						break;
					case 3:
						PostOrder(root);
						break;
					case 4:
						exit(0);
					default:
						cout<<endl<<"Invalid Choice.";
			}
			}while(ch != 4);
		}
};
int main()
{
	Binary_Tree bt;
	bt.create();
	return (0);
}
