#include <iostream>
using namespace std;
struct Node
{
    int data;
    Node *left, *right;
};

Node* newNode(int key)
{
    Node* node = new Node;
    node->data = key;
    node->left = node->right = nullptr;
 
    return node;
}
void inorder(Node* root)
{
    if (root == nullptr) {
        return;
    }
    inorder(root->left);
    cout << root->data <<"  ";
    inorder(root->right);
}
Node* findMaximumKey(Node* ptr)
{
    while (ptr->right != nullptr) {
        ptr = ptr->right;
    }
    return ptr;
}
Node* insert(Node* root, int key)
{
    if (root == nullptr) {
        return newNode(key);
    }
    if (key < root->data) {
        root->left = insert(root->left, key);
    }
    else {
        root->right = insert(root->right, key);
    }
    return root;
}
void deleteNode(Node* &root, int key)
{
    if (root == nullptr) {
        return;
    }
    if (key < root->data) {
        deleteNode(root->left, key);
    }
    else if (key > root->data) {
        deleteNode(root->right, key);
    }
    else {
        if (root->left == nullptr && root->right == nullptr)
        {
            delete root;
            root = nullptr;
        }
        else if (root->left && root->right)
        {
            Node* predecessor = findMaximumKey(root->left);
 
            root->data = predecessor->data;
            
            deleteNode(root->left, predecessor->data);
        }
        else {
            Node* child = (root->left)? root->left: root->right;
            Node* curr = root;
 
            root = child;
 
            delete curr;
        }
    }
}
 
int main()
{
	int ch;	
    Node* root = nullptr;
    int key;
	do
	{
		cout<<endl<<"\nMenu \n1)Insert Node \n2)Delete Node \n3)Display Inorder (Ascending Order) \n4)Exit \nEnter your choice : ";
		cin>>ch;
		switch(ch)
		{
			case 1:
				cout<<"\nEnter node value to be inserted : ";
				cin>>key;
				root = insert(root, key);
				break;
			case 2:
				cout<<"\nEnter node value to be deleted : ";
				cin>>key;
				deleteNode(root, key);
				break;
			case 3:
				cout<<"\nNodes present in BST : ";
				inorder(root);
				break;
			case 4:
				exit(0);
			default:
				cout<<endl<<"Invalid Choice.";
		}
	}while(ch != 4);
  
    return 0;
}
