#include<iostream>
#include<String.h>
#include<stdlib.h>
using namespace std;
class fold_boundary
{
	public:
		long int n,ch,*arr,key,loc,flag,len_Of_Set,no_Of_Zeros=0,no_Of_Parts,key_len,temp,add_Of_Key_Set,starting_Index,val_For_Mod,len_Add_Key_Set;
		string input,key_str,key_set[50],boundary,str_Val_For_Mod,str_Add_Of_Key_Set; 
		void initialize()
		{
			cout<<endl<<"Enter number of locations : ";
			cin>>n;
			arr = (long int*) malloc(n*sizeof(long int));
			for(int i=0;i<n;i++)
			{
				arr[i]=-1;
			}
			input=to_string(n-1);
			len_Of_Set=input.length();
		}
		void menu()
		{
			do
			{	
				cout<<endl<<"Menu:\n1.Add Key\n2.Display\n3.Exit"<<endl;
				cout<<endl<<"Enter choice : ";
				cin>>ch;
				switch(ch)
				{
					case 1:
						addKey();
						break;
					case 2:   
						display();
						break;
					case 3:
						exit(0);
					default:
						cout<<endl<<"Invalid choice.";
				}
			}while(1);
		}
		void addKey()
		{
			flag=0;
			for(int i=0;i<n;i++)
			{
				if(arr[i]==-1)
				{
					flag=1;
					break;
				}
			}
			if(flag==1)
			{
				cout<<endl<<"Enter number which you want to insert : ";
				cin>>key;
				
				key_str=to_string(key);
				
				key_len=key_str.length();
				
				no_Of_Parts=key_len/len_Of_Set;
				
				if(key_len%len_Of_Set!=0)
				{
					no_Of_Parts++;
					no_Of_Zeros=len_Of_Set - (key_len%len_Of_Set);
				}
				
				while(no_Of_Zeros!=0)
				{
					key_str="0"+key_str;
					no_Of_Zeros--;
				}
				
				temp=0;
				for(int i=0;i<no_Of_Parts;i++)
				{
					key_set[i]=key_str.substr(temp,len_Of_Set);
					temp=temp+len_Of_Set;						
				}	
				
				for(int i=0;i<no_Of_Parts;i++)
				{
					boundary="";
					if(i==0 || i==no_Of_Parts-1)
					{
						for(int j=len_Of_Set-1;j>=0;j--)
						{
							boundary+=key_set[i][j];
						}
						key_set[i]=boundary;
					}
				}	
				
				add_Of_Key_Set=0;
				for(int i=0;i<no_Of_Parts;i++)
				{
					add_Of_Key_Set+=stoi(key_set[i]);
				}
				
				str_Add_Of_Key_Set=to_string(add_Of_Key_Set);
				len_Add_Key_Set=str_Add_Of_Key_Set.length();
				starting_Index=len_Add_Key_Set%len_Of_Set;
				str_Val_For_Mod=str_Add_Of_Key_Set.substr(starting_Index,len_Of_Set);
				val_For_Mod=stoi(str_Val_For_Mod);
				loc=val_For_Mod%n;
				if(arr[loc]!=-1)
				{
					while(arr[loc]!=-1)
					{
						loc++;
						if(loc==n)
						{
							loc=0;
						}
					}
				}
				arr[loc]=key;
				cout<<endl<<key<<" added in hash table at location "<<loc;					
			}
			else
			{
				cout<<endl<<"Hash table is full.";	
			}		
		}
		void display()
		{
			flag=0;
			for(int i=0;i<n;i++)
			{
				if(arr[i]!=-1)
				{
					flag=1;
					break;
				}
			}
			if(flag==1)
			{
				cout<<endl<<"Hash table contains:";
				cout<<endl<<"Location        Key";
				for(int i=0;i<n;i++)
				{
					if(arr[i]!=-1)
					{
						cout<<endl<<"   "<<i<<"         "<<arr[i];	
					}
				}
				cout<<endl;
			}
			else
			{
				cout<<"Hash table is empty.";
			}
		}
};
int main()
{
	fold_boundary f1;
	f1.initialize();
	f1.menu();
	return 0;
}
