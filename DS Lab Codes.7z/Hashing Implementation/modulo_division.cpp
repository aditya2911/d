#include<iostream>
#include<stdlib.h>
using namespace std; 
class hashing
{
	public:
		int n,ch,*arr,key,loc,flag;
		void initialize()
		{
			cout<<endl<<"Enter number of locations : ";
			cin>>n;
			arr = (int*) malloc(n*sizeof(int));
			for(int i=0;i<n;i++)
			{
				arr[i]=-1;
			}
		}
		void menu()
		{
			do
			{	
				cout<<endl<<"Menu:\n1.Add Key\n2.Display\n3.Exit"<<endl;
				cout<<endl<<"Enter choice : ";
				cin>>ch;
				switch(ch)
				{
					case 1:
						addKey();
						break;
					case 2:
						display();
						break;
					case 3:
						exit(0);
					default:
						cout<<endl<<"Invalid choice.";
				}
			}while(1);
		}
		void addKey()
		{
			flag=0;
			for(int i=0;i<n;i++)
			{
				if(arr[i]==-1)
				{
					flag=1;
					break;
				}
			}
			if(flag==1)
			{
				cout<<endl<<"Enter key : ";
				cin>>key;
				loc=key%n;
				if(arr[loc]!=-1)
				{
					while(arr[loc]!=-1)
					{
						loc++;
						if(loc==n)
						{
							loc=0;
						}
					}
				} 
				arr[loc]=key;
				cout<<endl<<key<<" added in hash table at location "<<loc;
			}
			else
			{
				cout<<"Hash table is full.";
			}		
		}
		void display()
		{
			flag=0;
			for(int i=0;i<n;i++)
			{
				if(arr[i]!=-1)
				{
					flag=1;
					break;
				}
			}
			if(flag==1)
			{
				cout<<endl<<"Hash table contains:";
				cout<<endl<<"Location        Key";
				for(int i=0;i<n;i++)
				{
					if(arr[i]!=-1)
					{
						cout<<endl<<"   "<<i<<"            "<<arr[i];	
					}
				}
				cout<<endl;
			}
			else
			{
				cout<<"Hash table is empty.";
			}
		}
};
int main()
{
	hashing h1;
	h1.initialize();
	h1.menu();
}
